﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace distribution_copy.Models
{ 
        public class ProfileDetails
        {
            public string displayName { get; set; }
            public string publicAlias { get; set; }
            public string emailAddress { get; set; }
            public string id { get; set; }
            public string ErrorMessage { get; set; }
        }
    
}