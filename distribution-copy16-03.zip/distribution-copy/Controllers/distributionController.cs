﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace distribution_copy.Controllers
{
    public class distributionController : Controller
    {
        // GET: distribution
        public ActionResult Index()
        {
            return View();
        }
    }
}